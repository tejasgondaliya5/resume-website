from django.shortcuts import render, redirect
from .models import *
import smtplib
# Create your views here.
def home(request):
    return render(request, 'core/home.html', {'home':'active'})

def contect(request):
    if request.POST:
        name = request.POST['Name']
        email = request.POST['Email']
        subject = request.POST['Subject']
        message = request.POST['Message']

        obj = Contact()
        obj.Name = name
        obj.Email = email
        obj.Subject = subject
        obj.Message = message

        obj.save()

        print("processing")
        s = smtplib.SMTP('smtp.gmail.com', 587)
        s.starttls()
        s.login('tejasgondaliya5@gmail.com', 'Tejas@123')
        s.sendmail('tejasgondaliya5@gmail.com', email, f'Hello, {name} thanks for a Contect me. \n I am Try Qukliy Answar You Message. \n \n  This is My Emai_ID So You can Ask me any Qustion. I am Replay To some Time. If you are not wait For Time So You can Call Me, My Number Is Given A Site. \n Thanks For a Contect.')
        s.quit()

        return redirect('home')
    return render(request, 'core/contectus.html', {'contect':'active'})


